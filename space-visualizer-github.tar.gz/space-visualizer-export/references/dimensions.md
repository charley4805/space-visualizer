# Standard Dimension Reference Tables

All measurements: **imperial (inches) primary**, metric (cm) in parentheses.
Use these as anchors for scale calculation. Web-search only for specialty/custom items not listed here.

---

## BATHROOM

### Fixtures
| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Standard toilet | 14–18" (36–46cm) | 27–30" (69–76cm) | 28–30" (71–76cm) | Seat height 15–17" |
| Comfort-height toilet | 14–18" (36–46cm) | 27–30" (69–76cm) | 17–19" (43–48cm) seat | ADA standard |
| Wall-hung toilet | 14–18" (36–46cm) | 22–24" (56–61cm) | 15–17" (38–43cm) seat | Floating look |
| Single sink vanity | 24–48" (61–122cm) | 21–22" (53–56cm) | 32–36" (81–91cm) | To countertop |
| Double sink vanity | 48–72" (122–183cm) | 21–22" (53–56cm) | 32–36" (81–91cm) | |
| Pedestal sink | 24–27" (61–69cm) | 18–22" (46–56cm) | 33–36" (84–91cm) | |
| Vessel sink (bowl) | 14–20" (36–51cm) | 14–20" (36–51cm) | 5–7" (13–18cm) | Sits on counter |
| Bathroom mirror | 24–48" (61–122cm) | 1–2" (2.5–5cm) | 30–36" (76–91cm) | Typical above vanity |
| Medicine cabinet | 24–30" (61–76cm) | 4–6" (10–15cm) | 24–30" (61–76cm) | Recessed or surface |

### Tubs & Showers
| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Standard alcove tub | 60" (152cm) | 32" (81cm) | 18" (46cm) rim height | Most common |
| Freestanding soaking tub | 55–72" (140–183cm) | 27–32" (69–81cm) | 23–28" (58–71cm) | |
| Walk-in shower | 36×36" min (91×91cm) | — | 80–96" (203–244cm) | Standard 36×48 |
| Corner shower | 36×36" (91×91cm) | — | 80–96" (203–244cm) | |
| Shower door | 22–36" (56–91cm) | — | 72–80" (183–203cm) | |

### Storage & Hardware
| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Towel bar | 18–30" (46–76cm) | 3" (8cm) proj | 1" (2.5cm) | Mounted 48" AFF |
| Toilet paper holder | 6" (15cm) | 3" (8cm) proj | 2" (5cm) | Mounted 26" AFF |
| Shower niche | 12–16" (30–41cm) | 4–5" (10–13cm) | 12–24" (30–61cm) | Tiled inset |
| Linen closet | 24–30" (61–76cm) | 16–24" (41–61cm) | 80" (203cm) | Standard door |

### Tile & Surfaces
| Item | Standard Size | Notes |
|------|--------------|-------|
| Floor tile (small) | 12×12" (30×30cm) | Penny tile to 12" |
| Floor tile (large format) | 24×24" or 24×48" | Trending |
| Wall tile (subway) | 3×6" (8×15cm) | Classic |
| Wall tile (large) | 12×24" (30×61cm) | Modern |
| Grout line | 1/16"–1/8" (1.6–3mm) | Floor wider than wall |

---

## KITCHEN

### Cabinets
| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Base cabinet | 9–48" (23–122cm) | 24" (61cm) | 34.5" (88cm) | Without countertop |
| Wall cabinet | 9–48" (23–122cm) | 12" (30cm) | 30–42" (76–107cm) | |
| Tall pantry cabinet | 18–36" (46–91cm) | 24" (61cm) | 84–96" (213–244cm) | |
| Corner base cabinet | 36×36" (91×91cm) | 24" (61cm) | 34.5" (88cm) | Lazy Susan type |
| Countertop overhang | — | 25.5" (65cm) | 36" (91cm) AFF | 1.5" overhang |
| Backsplash height | — | — | 18" (46cm) | Between counter & wall cab |

### Appliances
| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Standard range/stove | 30" (76cm) | 25–27" (64–69cm) | 36" (91cm) | |
| Wide range | 36" (91cm) | 25–27" (64–69cm) | 36" (91cm) | |
| Dishwasher | 24" (61cm) | 24" (61cm) | 34.5" (88cm) | Built-in |
| Standard refrigerator | 30–36" (76–91cm) | 30–35" (76–89cm) | 65–70" (165–178cm) | |
| Counter-depth fridge | 30–36" (76–91cm) | 24–27" (61–69cm) | 65–70" (165–178cm) | |
| Microwave (OTR) | 30" (76cm) | 15–17" (38–43cm) | 16–18" (41–46cm) | Over-range |
| Kitchen sink (single) | 24–30" (61–76cm) | 21–22" (53–56cm) | 8–10" (20–25cm) depth | |
| Kitchen sink (double) | 32–36" (81–91cm) | 21–22" (53–56cm) | 8–10" (20–25cm) depth | |
| Kitchen faucet | 4–16" (10–41cm) spread | — | 8–16" (20–41cm) | |

---

## BEDROOM

| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Twin mattress | 38" (97cm) | 75" (190cm) | 9–12" (23–30cm) | |
| Full/Double mattress | 54" (137cm) | 75" (190cm) | 9–12" (23–30cm) | |
| Queen mattress | 60" (152cm) | 80" (203cm) | 9–12" (23–30cm) | Most common |
| King mattress | 76" (193cm) | 80" (203cm) | 9–12" (23–30cm) | |
| Bed frame (queen) | 63–65" (160–165cm) | 83–85" (211–216cm) | 14–36" (36–91cm) | Platform to tall |
| Nightstand | 18–24" (46–61cm) | 15–18" (38–46cm) | 24–28" (61–71cm) | |
| Dresser (horizontal) | 48–72" (122–183cm) | 18–20" (46–51cm) | 30–36" (76–91cm) | |
| Tall dresser/chest | 30–36" (76–91cm) | 18–20" (46–51cm) | 48–60" (122–152cm) | |
| Wardrobe/armoire | 36–72" (91–183cm) | 20–24" (51–61cm) | 72–84" (183–213cm) | |

---

## LIVING ROOM

| Item | Width | Depth | Height | Notes |
|------|-------|-------|--------|-------|
| Sofa (2-seat) | 52–64" (132–163cm) | 30–36" (76–91cm) | 33–38" (84–97cm) | |
| Sofa (3-seat) | 74–90" (188–229cm) | 30–36" (76–91cm) | 33–38" (84–97cm) | |
| Sectional (L-shape) | 100–120" (254–305cm) | 100–120" | 33–38" (84–97cm) | |
| Coffee table | 36–52" (91–132cm) | 18–24" (46–61cm) | 16–18" (41–46cm) | |
| TV stand/console | 48–72" (122–183cm) | 15–20" (38–51cm) | 20–28" (51–71cm) | |
| Bookshelf (standard) | 24–36" (61–91cm) | 10–12" (25–30cm) | 72–84" (183–213cm) | |
| Armchair | 28–35" (71–89cm) | 28–35" (71–89cm) | 30–38" (76–97cm) | |

---

## STRUCTURAL / ARCHITECTURAL

| Item | Standard Dimension | Notes |
|------|-------------------|-------|
| Interior wall thickness | 4.5" (11cm) | 2×4 stud + drywall both sides |
| Exterior wall thickness | 6.5–8" (16–20cm) | Includes insulation |
| Ceiling height (standard) | 96" / 8ft (244cm) | New construction |
| Ceiling height (older homes) | 84–90" / 7–7.5ft | Pre-1990 |
| Interior door (standard) | 32–36"W × 80"H (81–91 × 203cm) | |
| Bathroom door | 28–32"W × 80"H (71–81 × 203cm) | |
| Window (standard) | 24–48"W × 36–60"H | Varies widely |
| Baseboard height | 3–5" (8–13cm) | |
| Crown molding | 3–6" (8–15cm) | |
| Floor thickness (wood) | 0.75" (2cm) | Hardwood plank |
| Tile floor assembly | 1.5" (4cm) | Tile + mortar + backer |

---

## SCALE ANCHOR PRIORITY

When calculating scale from a photo, prefer these items as anchors (most reliable → least reliable):

1. **Standard door** — 80" tall, almost universal (best anchor)
2. **Standard toilet** — 28–30" deep, very consistent
3. **Electrical outlet** — 4.5" × 2.75" faceplate (precise but small)
4. **Kitchen appliance** — range 30"W, fridge 30–36"W
5. **Tile grout lines** — only if tile size is identifiable
6. **Light switch plate** — 4.5" × 2.75"
7. **Ceiling height** — 96" if modern construction

Use **two anchors when possible** to cross-validate the scale. If they disagree by >15%, flag it to the user.
