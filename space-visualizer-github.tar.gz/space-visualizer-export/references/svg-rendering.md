# SVG Rendering Guide

## Coordinate System

Use a virtual canvas of **1200×900px** for landscape rooms, **900×1200px** for portrait.

SVG units = inches at the calculated scale. Example: if 1 SVG unit = 0.5 inches real-world,
a 30" wide item = 60 SVG units wide.

Always define a `<defs>` block at the top with patterns and reusable symbols.

---

## Mode 1: Blueprint Diagram

### Visual Language
- **Background**: `#f0f4f8` (light blueprint paper)
- **Grid**: `#c5d5e8` lines at every 12" (1 foot) real-world equivalent
- **Walls**: `#1a2d4a` fill, 4.5" thick (scaled)
- **Item outlines**: `#1a2d4a` stroke, 1.5px, `#dce8f5` fill
- **Dimension lines**: `#e84040` stroke, 0.75px, with arrowheads
- **Dimension text**: `#e84040`, font-size 10px, font-family monospace
- **Item labels**: `#1a2d4a`, font-size 9px, centered on item
- **Layer labels**: `#6b8cae`, font-size 8px, italic

### Grid Pattern
```svg
<defs>
  <pattern id="grid" width="FOOT_PX" height="FOOT_PX" patternUnits="userSpaceOnUse">
    <path d="M FOOT_PX 0 L 0 0 0 FOOT_PX" fill="none" stroke="#c5d5e8" stroke-width="0.5"/>
  </pattern>
  <pattern id="grid-major" width="FOOT5_PX" height="FOOT5_PX" patternUnits="userSpaceOnUse">
    <rect width="FOOT5_PX" height="FOOT5_PX" fill="url(#grid)"/>
    <path d="M FOOT5_PX 0 L 0 0 0 FOOT5_PX" fill="none" stroke="#a0b8d0" stroke-width="1"/>
  </pattern>
  <marker id="arrow" markerWidth="6" markerHeight="6" refX="3" refY="3" orient="auto">
    <path d="M0,0 L0,6 L6,3 z" fill="#e84040"/>
  </marker>
</defs>
<rect width="100%" height="100%" fill="#f0f4f8"/>
<rect width="100%" height="100%" fill="url(#grid-major)"/>
```

### Dimension Line Helper
```svg
<!-- Horizontal dimension line -->
<g class="dim">
  <line x1="X1" y1="Y" x2="X2" y2="Y" stroke="#e84040" stroke-width="0.75"
        marker-start="url(#arrow)" marker-end="url(#arrow)"/>
  <!-- Extension lines -->
  <line x1="X1" y1="ITEM_TOP" x2="X1" y2="Y+4" stroke="#e84040" stroke-width="0.5" stroke-dasharray="2,2"/>
  <line x1="X2" y1="ITEM_TOP" x2="X2" y2="Y+4" stroke="#e84040" stroke-width="0.5" stroke-dasharray="2,2"/>
  <text x="MID_X" y="Y-3" text-anchor="middle" fill="#e84040" font-size="9" font-family="monospace">30"</text>
</g>
```

### Layer Rendering Order (back to front)
1. Grid background
2. Walls (filled rectangles, thickness scaled)
3. Floor material pattern (tile grid, wood planks)
4. Fixed floor items (tub, toilet base)
5. Wall-mounted items (vanity, cabinets)
6. Countertops / surfaces
7. Items on surfaces (faucets, accessories)
8. Ceiling elements (lights, vents) — dashed outline
9. Dimension lines
10. Item labels
11. Scale bar + title block

### Scale Bar (always include)
```svg
<g transform="translate(CANVAS_W - 160, CANVAS_H - 40)">
  <!-- Scale bar: 5 feet -->
  <rect x="0" y="0" width="FIVE_FEET_PX" height="8" fill="#1a2d4a"/>
  <text x="FIVE_FEET_PX/2" y="20" text-anchor="middle" fill="#1a2d4a" font-size="9" font-family="monospace">5'-0"</text>
  <text x="FIVE_FEET_PX/2" y="30" text-anchor="middle" fill="#6b8cae" font-size="7" font-family="monospace">SCALE: 1"=Xft</text>
</g>
```

### Title Block (bottom-left)
```svg
<g transform="translate(10, CANVAS_H - 50)">
  <text font-size="14" font-weight="bold" fill="#1a2d4a" font-family="monospace">ROOM TYPE — BLUEPRINT</text>
  <text y="16" font-size="8" fill="#6b8cae" font-family="monospace">Generated from photo analysis • Claude Space Visualizer</text>
  <text y="28" font-size="8" fill="#6b8cae" font-family="monospace">Items: [ITEM LIST] • Scale: 1 SVG unit = X inches</text>
</g>
```

---

## Mode 2: Remodel Vision

### Visual Language — Architectural Illustration Style
- **Background**: `#fafaf8` (warm white)
- **Walls**: Gradient fills — light source from top-left
  - Front wall: `#e8e4de`
  - Side wall (left): `#d4cec6`
  - Floor: `#c8bfb0` or tile pattern
  - Ceiling: `#f0ede8`
- **Fixtures**: Slightly desaturated, realistic color hints
  - Ceramic/porcelain: `#f5f3f0` with subtle shadow
  - Wood (cabinets): `#c4a882` grain-hinted
  - Chrome/metal: `#d0d4d8` with highlight line
  - Glass: semi-transparent `rgba(200,220,240,0.3)`
- **Shadows**: Soft drop shadows on all 3D items
- **New items** (remodel additions): Slight warm highlight `rgba(255,200,100,0.15)` overlay + dashed border to distinguish
- **Annotations**: Clean callout lines with pill-shaped labels

### Perspective / Isometric Drawing

For matching photo angle, choose based on room type:

**Bathroom/Small room (3-point perspective feel):**
```
Vanishing points: VP-Left at (-200, 400), VP-Right at (1400, 400)
Horizon line: y = 380px (about 42% down — eye level at ~5ft)
```

**Kitchen (2-point perspective):**
```
VP-Left at (-300, 380), VP-Right at (1500, 380)
Horizon: y = 380px
```

**Helper: Draw a cabinet in perspective**
```svg
<!-- Cabinet box in 2-point perspective -->
<!-- Front face -->
<polygon points="FL_X,FL_Y FR_X,FR_Y BR_X,BR_Y BL_X,BL_Y" fill="#c4a882" stroke="#8a6e55" stroke-width="1"/>
<!-- Side face (darker) -->
<polygon points="FR_X,FR_Y SR_X,SR_Y SBR_X,SBR_Y BR_X,BR_Y" fill="#a88a6e" stroke="#8a6e55" stroke-width="1"/>
<!-- Top face (lightest) -->
<polygon points="TFL_X,TFL_Y TFR_X,TFR_Y TSR_X,TSR_Y TBL_X,TBL_Y" fill="#d4b896" stroke="#8a6e55" stroke-width="0.5"/>
```

### Lighting & Shadows
```svg
<defs>
  <!-- Ambient room light -->
  <radialGradient id="roomLight" cx="30%" cy="20%" r="70%">
    <stop offset="0%" stop-color="rgba(255,255,240,0.4)"/>
    <stop offset="100%" stop-color="rgba(0,0,0,0)"/>
  </radialGradient>
  <!-- Soft drop shadow -->
  <filter id="shadow" x="-10%" y="-10%" width="120%" height="130%">
    <feDropShadow dx="3" dy="4" stdDeviation="4" flood-color="rgba(0,0,0,0.2)"/>
  </filter>
  <!-- New item highlight -->
  <filter id="newItemGlow">
    <feDropShadow dx="0" dy="0" stdDeviation="6" flood-color="rgba(255,180,50,0.5)"/>
  </filter>
</defs>
```

### New Item Callout (remodel additions)
```svg
<g class="callout-new">
  <!-- Dashed border on new item -->
  <rect x="X" y="Y" width="W" height="H" fill="rgba(255,200,100,0.1)"
        stroke="#f0a030" stroke-width="1.5" stroke-dasharray="5,3" rx="2"/>
  <!-- Callout line -->
  <line x1="ITEM_CX" y1="ITEM_TOP" x2="LABEL_X" y2="LABEL_Y"
        stroke="#f0a030" stroke-width="1"/>
  <!-- Label pill -->
  <rect x="LABEL_X-4" y="LABEL_Y-12" width="LABEL_W+8" height="16"
        fill="#f0a030" rx="8"/>
  <text x="LABEL_X + LABEL_W/2" y="LABEL_Y" text-anchor="middle"
        fill="white" font-size="9" font-weight="bold" font-family="sans-serif">NEW: Item Name</text>
</g>
```

### Material Patterns (reuse in defs)
```svg
<!-- Subway tile wall pattern -->
<pattern id="subwayTile" width="24" height="12" patternUnits="userSpaceOnUse">
  <rect width="24" height="12" fill="#f0ede8"/>
  <rect x="0.5" y="0.5" width="22" height="10" fill="#f8f6f3" rx="0.5"/>
  <!-- Offset second row -->
  <rect x="-11.5" y="12.5" width="22" height="10" fill="#f8f6f3" rx="0.5"/>
  <rect x="12.5" y="12.5" width="22" height="10" fill="#f8f6f3" rx="0.5"/>
</pattern>

<!-- 12x12 floor tile -->
<pattern id="floorTile" width="40" height="40" patternUnits="userSpaceOnUse">
  <rect width="40" height="40" fill="#c8bfb0"/>
  <rect x="0.5" y="0.5" width="38" height="38" fill="#d4cab8"/>
</pattern>

<!-- Wood plank floor -->
<pattern id="woodFloor" width="20" height="80" patternUnits="userSpaceOnUse">
  <rect width="20" height="80" fill="#b8965a"/>
  <rect x="1" y="1" width="18" height="78" fill="#c4a268"/>
  <line x1="0" y1="40" x2="20" y2="40" stroke="#a07840" stroke-width="0.5"/>
</pattern>
```

---

## Measurement Overlay (both modes)

Show dimensions in user's chosen system. Default: show both.

```
Format: 5'-6" (167cm)
         W: 30" (76cm)   H: 32" (81cm)   D: 21" (53cm)
```

For inline rendering, use 10-12px font. For SVG download, use 9-10px (renders sharper at full resolution).

---

## Scale Calculation Procedure

```
1. Identify best anchor item in photo (see dimensions.md anchor priority list)
2. Measure anchor item in pixels: px_height or px_width
3. Look up real dimension from dimensions.md
4. SCALE = real_inches / px_measured
5. Verify with second anchor if available
6. Report: "Scale: 1px ≈ X inches (1 SVG unit = Y inches)"
7. Apply scale to ALL items in scene
8. If perspective distortion detected: note which items may be ±15% off
```

## Uncertainty Handling

When an item's real dimensions can't be confidently determined:
- Show dimension as range: `30–36" (76–91cm)`
- Add `~` prefix: `~30" (76cm)`
- Add footnote: `* Estimated — verify before construction`
- Flag items needing web search vs. items using built-in tables
